package app.moment
import android.app.*
import android.content.*
import kotlinx.coroutines.*

fun leadText(m: Int) = if (m >= 60) "${m / 60} ч" + (if (m % 60 > 0) " ${m % 60} мин" else "") else "$m мин"

object Notifier {
    private fun prefs(c: Context) = c.getSharedPreferences("m", 0)
    private fun nm(c: Context): NotificationManager {
        val n = c.getSystemService(NotificationManager::class.java)
        n.createNotificationChannel(NotificationChannel("bar", "Ближайшее дело", NotificationManager.IMPORTANCE_LOW))
        n.createNotificationChannel(NotificationChannel("rem", "Напоминания", NotificationManager.IMPORTANCE_HIGH))
        n.createNotificationChannel(NotificationChannel("quiet", "Напоминания (тихо)", NotificationManager.IMPORTANCE_LOW))
        return n
    }
    private fun open(c: Context) = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    fun refresh(c: Context) { CoroutineScope(Dispatchers.IO).launch {
        val items = Db.get(c).dao().upcoming(System.currentTimeMillis())
        val n = nm(c); val p = prefs(c); val next = items.firstOrNull()
        if (!p.getBoolean("bar", true) || next == null) n.cancel(1) else n.notify(1,
            Notification.Builder(c, "bar").setSmallIcon(android.R.drawable.ic_menu_my_calendar).setContentTitle(next.title)
                .setContentText(next.hm() + " · " + next.rel()).setWhen(next.start ?: 0).setShowWhen(true).setUsesChronometer(true)
                .setChronometerCountDown(true).setOngoing(true).setOnlyAlertOnce(true).setContentIntent(open(c)).build())
        var bt = Long.MAX_VALUE; var bi = 0L; var bl = 0
        val now = System.currentTimeMillis()
        val leads = if (p.getBoolean("rem", true)) (p.getString("leads", "120,90,5") ?: "").split(",").mapNotNull { it.toIntOrNull() } else emptyList()
        for (i in items) { val s = i.start ?: continue
            for (l in leads + 0 + -1) { val t = if (l < 0) s + i.minutes * 60_000L else s - l * 60_000L
                if (t > now && t < bt) { bt = t; bi = i.id; bl = l } } }
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(c, 7, Intent(c, AlarmReceiver::class.java).putExtra("id", bi).putExtra("lead", bl), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (bt == Long.MAX_VALUE) am.cancel(pi) else try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bt, pi) } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, bt, pi) }
    } }

    fun alert(c: Context, i: Item, lead: Int) {
        val quiet = prefs(c).getBoolean("quiet", false) && java.time.LocalTime.now().hour.let { it >= 23 || it < 8 }
        nm(c).notify(100 + (i.id % 1000).toInt(), Notification.Builder(c, if (quiet) "quiet" else "rem").setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle(i.title).setContentText("Через " + leadText(lead) + " · " + i.hm()).setAutoCancel(true).setContentIntent(open(c)).build())
    }
    fun test(c: Context) = alert(c, Item(id = 1, title = "Так будет выглядеть напоминание", start = System.currentTimeMillis() + 300_000), 5)
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = goAsync(); val id = i.getLongExtra("id", 0); val lead = i.getIntExtra("lead", 0)
        CoroutineScope(Dispatchers.IO).launch {
            if (lead > 0) Db.get(c).dao().get(id)?.let { Notifier.alert(c, it, lead) }
            Notifier.refresh(c); p.finish()
        }
    }
}
class BootReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = Notifier.refresh(c) }
