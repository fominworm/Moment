package app.moment
import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider

class NextWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val n = Db.get(context).dao().next(System.currentTimeMillis())
        provideContent {
            val c = n?.let { Palette[it.color] } ?: Color.Gray
            Row(
                GlanceModifier.fillMaxSize().cornerRadius(28.dp).background(ColorProvider(Color(0xFF17142E)))
                    .padding(18.dp).clickable(actionStartActivity(Intent(context, MainActivity::class.java))),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(GlanceModifier.width(5.dp).height(56.dp).cornerRadius(3.dp).background(ColorProvider(c))) {}
                Spacer(GlanceModifier.width(14.dp))
                Column {
                    Text(n?.whenText() ?: "Свободно", style = TextStyle(color = ColorProvider(c), fontSize = 14.sp, fontWeight = FontWeight.Medium))
                    Text(n?.title ?: "Событий нет", maxLines = 2, style = TextStyle(color = ColorProvider(Color.White), fontSize = 21.sp, fontWeight = FontWeight.Bold))
                    Text(n?.sub() ?: "Отдыхай", maxLines = 1, style = TextStyle(color = ColorProvider(Color(0x99FFFFFF)), fontSize = 14.sp))
                }
            }
        }
    }
}
class NextWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = NextWidget() }
