package app.moment
import android.content.Context
import android.content.Intent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider

class NextWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(setOf(DpSize(200.dp, 100.dp), DpSize(200.dp, 230.dp)))
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val list = Db.get(context).dao().upcoming(System.currentTimeMillis()).take(20)
        val raw = context.getSharedPreferences("m", 0).getInt("w", 0)
        val idx = if (list.isEmpty()) 0 else ((raw % list.size) + list.size) % list.size
        provideContent {
            val open = actionStartActivity(Intent(context, MainActivity::class.java))
            val big = LocalSize.current.height >= 200.dp
            @androidx.compose.runtime.Composable fun Line(n: Item?, titleSize: Int, m: GlanceModifier) {
                val c = n?.let { Palette[it.color] } ?: Color.Gray
                Row(m, verticalAlignment = Alignment.CenterVertically) {
                    Box(GlanceModifier.width(5.dp).height(if (titleSize > 18) 54.dp else 40.dp).cornerRadius(3.dp).background(ColorProvider(c))) {}
                    Spacer(GlanceModifier.width(12.dp))
                    Column {
                        Text(n?.whenText() ?: "Свободно", style = TextStyle(color = ColorProvider(c), fontSize = 13.sp, fontWeight = FontWeight.Medium))
                        Text(n?.title ?: "Событий нет", maxLines = 1, style = TextStyle(color = ColorProvider(Color.White), fontSize = titleSize.sp, fontWeight = FontWeight.Bold))
                        if (titleSize > 18) Text(n?.sub() ?: "", maxLines = 1, style = TextStyle(color = ColorProvider(Color(0x99FFFFFF)), fontSize = 13.sp))
                    }
                }
            }
            if (big) Column(GlanceModifier.fillMaxSize().background(ImageProvider(R.drawable.widget_bg)).padding(16.dp).clickable(open), verticalAlignment = Alignment.CenterVertically) {
                if (list.isEmpty()) Line(null, 20, GlanceModifier.fillMaxWidth())
                list.take(3).forEach { Line(it, 17, GlanceModifier.fillMaxWidth().padding(vertical = 7.dp)) }
            } else Row(GlanceModifier.fillMaxSize().background(ImageProvider(R.drawable.widget_bg)).padding(start = 18.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(GlanceModifier.defaultWeight().clickable(open)) { Line(list.getOrNull(idx), 21, GlanceModifier.fillMaxWidth()) }
                if (list.size > 1) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⌃", modifier = GlanceModifier.clickable(actionRunCallback(PrevCb::class.java)).padding(10.dp), style = TextStyle(color = ColorProvider(Color.White), fontSize = 20.sp))
                    Text("⌄", modifier = GlanceModifier.clickable(actionRunCallback(NextCb::class.java)).padding(10.dp), style = TextStyle(color = ColorProvider(Color.White), fontSize = 20.sp))
                }
            }
        }
    }
}
private suspend fun step(c: Context, id: GlanceId, d: Int) {
    val p = c.getSharedPreferences("m", 0); p.edit().putInt("w", p.getInt("w", 0) + d).apply(); NextWidget().update(c, id)
}
class NextCb : ActionCallback { override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) = step(context, glanceId, 1) }
class PrevCb : ActionCallback { override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) = step(context, glanceId, -1) }
class NextWidgetReceiver : GlanceAppWidgetReceiver() { override val glanceAppWidget = NextWidget() }
