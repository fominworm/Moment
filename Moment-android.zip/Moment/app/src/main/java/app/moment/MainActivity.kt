package app.moment
import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.background
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Acc)) { App() } }
    }
}

@Composable fun App(vm: VM = viewModel()) {
    val items by vm.items.collectAsState()
    val ctx = LocalContext.current
    val prefs = ctx.getSharedPreferences("m", 0)
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { S.load(prefs); Notifier.refresh(ctx); if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS) }
    var tab by remember { mutableIntStateOf(0) }
    var edit by remember { mutableStateOf<Item?>(null) }
    val host = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val open: (Item) -> Unit = { edit = it }
    val del: (Item) -> Unit = { i ->
        vm.del(i); edit = null
        scope.launch { if (host.showSnackbar("Удалено", "Вернуть") == SnackbarResult.ActionPerformed) vm.save(i) }
    }
    Aurora {
      AnimatedContent(splash, transitionSpec = { fadeIn(tween(500)) togetherWith fadeOut(tween(400)) }, label = "s") { sp -> if (sp) Splash { splash = false } else Box(Modifier.fillMaxSize()) {
        AnimatedContent(tab, transitionSpec = { (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 20 }) togetherWith fadeOut(tween(140)) }, label = "tab") { t ->
            when (t) { 0 -> Home(items, open) { tab = it }; 1 -> Cal(items, open); 2 -> Notes(items, open); else -> SettingsScreen(prefs) }
        }
        SnackbarHost(host, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 100.dp))
        if (tab < 3) Box(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 24.dp, bottom = 106.dp)
            .shadow(20.dp, CircleShape, spotColor = Acc).size(62.dp).background(Brush.linearGradient(listOf(Acc, Color(0xFF5B8CFF))), CircleShape)
            .tap { edit = Item(title = "", start = if (tab == 2) null else LocalDateTime.now().plusHours(1).truncatedTo(ChronoUnit.HOURS).ms()) },
            Alignment.Center) { Icon(Icons.Outlined.Add, null, tint = Color.White) }
        NavBar(tab, Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(20.dp, 0.dp, 20.dp, 18.dp)) { tab = it }
    } } }
    edit?.let { Editor(it, { s -> vm.save(s); edit = null }, del) { edit = null } }
}
