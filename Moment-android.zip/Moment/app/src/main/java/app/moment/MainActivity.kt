package app.moment
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); enableEdgeToEdge()
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) { App() } }
    }
}

@Composable fun App(vm: VM = viewModel()) {
    val items by vm.items.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var add by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color(0xFF07070F)).drawBehind {
        drawCircle(Brush.radialGradient(listOf(Color(0x558B6CFF), Color.Transparent), Offset(size.width, 0f), size.width * .9f), size.width * .9f, Offset(size.width, 0f))
        drawCircle(Brush.radialGradient(listOf(Color(0x335B8CFF), Color.Transparent), Offset(0f, size.height), size.width), size.width, Offset(0f, size.height))
    }) {
        AnimatedContent(tab, transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(160)) }, label = "tab") { t ->
            when (t) { 0 -> Home(items, vm::del); 1 -> Cal(items, vm::del); else -> Notes(items, vm::del) }
        }
        Box(Modifier.align(Alignment.BottomEnd).padding(end = 24.dp, bottom = 116.dp).navigationBarsPadding().size(60.dp)
            .clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF8B6CFF), Color(0xFF5B8CFF))))
            .clickable { add = true }, Alignment.Center) { Icon(Icons.Default.Add, null, tint = Color.White) }
        Row(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(20.dp, 0.dp, 20.dp, 20.dp)
            .fillMaxWidth().glass(32.dp).padding(8.dp), Arrangement.SpaceAround) {
            listOf(Icons.Outlined.Home, Icons.Outlined.CalendarMonth, Icons.Outlined.EditNote).forEachIndexed { i, ic ->
                Box(Modifier.clip(RoundedCornerShape(24.dp)).background(if (tab == i) Color(0x33FFFFFF) else Color.Transparent)
                    .clickable { tab = i }.padding(horizontal = 30.dp, vertical = 12.dp)) { Icon(ic, null, tint = Color.White) }
            }
        }
    }
    if (add) AddSheet { it?.let(vm::add); add = false }
}
