package app.moment
import android.app.Application
import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

val ru = Locale("ru")

@Entity data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val body: String = "", val color: Int = 0,
    val start: Long? = null, val minutes: Int = 60)

@Dao interface ItemDao {
    @Query("SELECT * FROM Item ORDER BY id DESC") fun all(): Flow<List<Item>>
    @Insert suspend fun add(i: Item)
    @Delete suspend fun del(i: Item)
    @Query("SELECT * FROM Item WHERE start >= :now ORDER BY start LIMIT 1") suspend fun next(now: Long): Item?
}

@Database(entities = [Item::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): ItemDao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context) = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "moment.db").build().also { i = it }
        }
    }
}

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    val items = dao.all().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun add(i: Item) = viewModelScope.launch { dao.add(i); NextWidget().updateAll(getApplication()) }
    fun del(i: Item) = viewModelScope.launch { dao.del(i); NextWidget().updateAll(getApplication()) }
}

fun Item.whenText(): String {
    val s = start ?: return "Заметка"
    val dt = Instant.ofEpochMilli(s).atZone(ZoneId.systemDefault())
    val day = when (ChronoUnit.DAYS.between(LocalDate.now(), dt.toLocalDate())) {
        0L -> "Сегодня"; 1L -> "Завтра"
        else -> dt.format(DateTimeFormatter.ofPattern("d MMMM", ru))
    }
    return dt.format(DateTimeFormatter.ofPattern("HH:mm")) + " · " + day
}
