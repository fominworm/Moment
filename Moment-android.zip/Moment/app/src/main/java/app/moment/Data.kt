package app.moment
import android.app.Application
import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

val ru = Locale("ru")

@Entity data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val body: String = "", val color: Int = 0,
    val start: Long? = null, val minutes: Int = 60, val cat: Int = 0, val place: String = "")

@Dao interface ItemDao {
    @Query("SELECT * FROM Item ORDER BY id DESC") fun all(): Flow<List<Item>>
    @Upsert suspend fun save(i: Item)
    @Query("SELECT * FROM Item WHERE start + minutes * 60000 >= :now ORDER BY start") suspend fun upcoming(now: Long): List<Item>
    @Query("SELECT * FROM Item WHERE id = :id") suspend fun get(id: Long): Item?
    @Delete suspend fun del(i: Item)
    @Query("SELECT * FROM Item WHERE start + minutes * 60000 >= :now ORDER BY start LIMIT 1") suspend fun next(now: Long): Item?
}

@Database(entities = [Item::class], version = 2, exportSchema = false)
abstract class Db : RoomDatabase() {
    abstract fun dao(): ItemDao
    companion object {
        @Volatile private var i: Db? = null
        fun get(c: Context) = i ?: synchronized(this) {
            i ?: Room.databaseBuilder(c.applicationContext, Db::class.java, "moment.db")
                .fallbackToDestructiveMigration().build().also { i = it }
        }
    }
}

class VM(app: Application) : AndroidViewModel(app) {
    private val dao = Db.get(app).dao()
    val items = dao.all().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    fun save(i: Item) = viewModelScope.launch { dao.save(i); NextWidget().updateAll(getApplication()); Notifier.refresh(getApplication()) }
    fun del(i: Item) = viewModelScope.launch { dao.del(i); NextWidget().updateAll(getApplication()); Notifier.refresh(getApplication()) }
}

fun Item.dt(): ZonedDateTime? = start?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()) }
fun LocalDateTime.ms(): Long = atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
fun Item.hm(): String = dt()?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: ""
fun Item.sub(): String = listOfNotNull(place.ifBlank { null }, if (start == null) null else if (minutes == 60) "1 час" else "$minutes мин").joinToString(" · ")

fun Item.rel(): String {
    val z = dt() ?: return "Заметка"
    val m = ChronoUnit.MINUTES.between(ZonedDateTime.now(), z)
    val d = ChronoUnit.DAYS.between(LocalDate.now(), z.toLocalDate())
    return when {
        m < 0 -> "Идёт сейчас"
        m < 60 -> "Через $m мин"
        d == 0L -> "Через ${m / 60} ч"
        d == 1L -> "Завтра"
        d < 7 -> z.format(DateTimeFormatter.ofPattern("EEEE", ru)).replaceFirstChar { it.uppercase() }
        else -> z.format(DateTimeFormatter.ofPattern("d MMMM", ru))
    }
}
fun Item.whenText() = if (start == null) "Заметка" else hm() + " · " + rel()
