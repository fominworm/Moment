package app.moment
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import java.time.*
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

object S { var accent by mutableIntStateOf(0); var sunday by mutableStateOf(false) }
val Palette = listOf(Color(0xFFB794FF), Color(0xFF7FB6FF), Color(0xFF7DF0C0), Color(0xFFFFB38A), Color(0xFFFF8FB8))
val Acc get() = Palette[S.accent]
val Dim = Color(0x99FFFFFF)
val Cats = listOf("Личные", "Учёба", "Идеи", "Работа")
val Bold = FontWeight.Bold
val Semi = FontWeight.SemiBold

@Composable fun Aurora(content: @Composable BoxScope.() -> Unit) {
    val t by rememberInfiniteTransition(label = "a").animateFloat(0f, 1f, infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    val acc = Acc
    Box(Modifier.fillMaxSize().background(Color(0xFF06060E)).drawBehind {
        val w = size.width; val h = size.height
        fun blob(c: Color, x: Float, y: Float, r: Float) = drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(x, y), r), r, Offset(x, y))
        blob(acc.copy(.42f), w * (.95f - .3f * t), h * (.02f + .08f * t), w * 1.0f)
        blob(Color(0x405B8CFF), w * (.05f + .25f * t), h * (.96f - .1f * t), w * 1.1f)
        blob(Color(0x267DF0C0), w * .95f, h * (.55f + .15f * t), w * .7f)
        drawCircle(Color(0x18FFFFFF), w * 1.15f, Offset(w * 1.05f, -h * .02f), style = Stroke(1.5.dp.toPx()))
        drawCircle(Color(0x10FFFFFF), w * .8f, Offset(-w * .1f, h * 1.02f), style = Stroke(1.5.dp.toPx()))
    }, content = content)
}

fun Modifier.glass(r: Dp = 28.dp, tint: Color = Color.White): Modifier {
    val s = RoundedCornerShape(r)
    return clip(s).background(Brush.verticalGradient(listOf(tint.copy(.16f), tint.copy(.05f))))
        .border(1.dp, Brush.linearGradient(listOf(Color(0x55FFFFFF), Color(0x0AFFFFFF), Color(0x22FFFFFF))), s)
}

fun Modifier.tap(f: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val p by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (p) .96f else 1f, spring(dampingRatio = .55f), label = "p")
    val h = LocalHapticFeedback.current
    graphicsLayer { scaleX = sc; scaleY = sc }.clickable(src, null) { h.performHapticFeedback(HapticFeedbackType.TextHandleMove); f() }
}

@Composable fun T(s: String, size: Int, c: Color = Color.White, w: FontWeight = FontWeight.Normal, m: Modifier = Modifier, lines: Int = Int.MAX_VALUE, a: TextAlign? = null) =
    Text(s, m, c, size.sp, fontWeight = w, maxLines = lines, textAlign = a)

@Composable fun Chip(s: String, on: Boolean, f: () -> Unit) {
    val bg by animateColorAsState(if (on) Acc else Color(0x1FFFFFFF), tween(250), label = "c")
    Box(Modifier.tap(f).clip(CircleShape).background(bg).padding(16.dp, 9.dp)) { T(s, 14, w = if (on) Semi else FontWeight.Normal) }
}

@Composable fun NavBar(tab: Int, m: Modifier, go: (Int) -> Unit) {
    val icons = listOf(Icons.Outlined.Home, Icons.Outlined.CalendarMonth, Icons.Outlined.EditNote, Icons.Outlined.Settings)
    BoxWithConstraints(m.fillMaxWidth().height(66.dp).glass(34.dp)) {
        val w = maxWidth / 4
        val x by animateDpAsState(w * tab, spring(dampingRatio = .75f, stiffness = 380f), label = "x")
        Box(Modifier.offset(x).width(w).fillMaxHeight().padding(7.dp).clip(CircleShape).background(Color(0x30FFFFFF)))
        Row { icons.forEachIndexed { i, ic -> Box(Modifier.weight(1f).fillMaxHeight().tap { go(i) }, Alignment.Center) { Icon(ic, null, tint = if (tab == i) Color.White else Dim) } } }
    }
}

@Composable fun Strip(i: Item, m: Modifier, open: (Item) -> Unit) {
    val c = Palette[i.color]
    Row(m.fillMaxWidth().tap { open(i) }.glass(26.dp).padding(18.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(58.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.clip(CircleShape).background(c.copy(.22f)).padding(12.dp, 3.dp)) { T(i.hm(), 16, c, Semi) }
                T(i.rel(), 14, Dim)
            }
            T(i.title, 20, w = Semi, lines = 1)
            if (i.sub().isNotEmpty()) T(i.sub(), 14, Dim, lines = 1)
        }
        Icon(Icons.Outlined.ChevronRight, null, tint = Dim)
    }
}

@Composable fun NoteRow(i: Item, m: Modifier, open: (Item) -> Unit) {
    Row(m.fillMaxWidth().tap { open(i) }.glass(22.dp).padding(18.dp, 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(Palette[i.color]))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { T(i.title, 18, w = Semi, lines = 1); if (i.body.isNotBlank()) T(i.body, 14, Dim, lines = 1) }
    }
}

@Composable fun Head(s: String, right: String, go: () -> Unit) =
    Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        T(s, 22, m = Modifier.weight(1f))
        Row(Modifier.tap(go), verticalAlignment = Alignment.CenterVertically) { T(right, 15, Dim); Icon(Icons.Outlined.ChevronRight, null, tint = Dim) }
    }

@Composable fun Home(items: List<Item>, open: (Item) -> Unit, go: (Int) -> Unit) {
    val now = System.currentTimeMillis()
    val soon = items.filter { (it.start ?: 0) + it.minutes * 60_000L >= now }.sortedBy { it.start }.take(3)
    val notes = items.filter { it.start == null }.take(3)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 64.dp, 20.dp, 180.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    T(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE · d MMMM", ru)).replaceFirstChar { it.uppercase() }, 16, Dim)
                    T("Твой день.", 46, w = Bold)
                }
                Box(Modifier.size(52.dp).tap { go(1) }.glass(26.dp), Alignment.Center) { Icon(Icons.Outlined.CalendarMonth, null, tint = Color.White) }
            }
        }
        item { val n = soon.size; Head("Ближайшее", "$n " + if (n == 1) "событие" else if (n in 2..4) "события" else "событий") { go(1) } }
        if (soon.isEmpty()) item { Box(Modifier.fillMaxWidth().glass(26.dp).padding(24.dp)) { T("Пока свободно. Нажми +, чтобы добавить событие", 15, Dim) } }
        items(soon, key = { it.id }) { i -> Strip(i, Modifier.animateItem(), open) }
        item { Head("Твои заметки", "Все") { go(2) } }
        items(notes, key = { it.id }) { i -> NoteRow(i, Modifier.animateItem(), open) }
    }
}

@Composable fun Cal(items: List<Item>, open: (Item) -> Unit) {
    var sel by remember { mutableStateOf(LocalDate.now()) }
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var week by remember { mutableStateOf(false) }
    val first = if (S.sunday) 7 else 1
    fun lead(d: LocalDate) = (d.dayOfWeek.value - first + 7) % 7
    fun Item.day() = dt()?.toLocalDate()
    val rows: List<List<LocalDate?>> = if (week) {
        val s = sel.minusDays(lead(sel).toLong()); listOf(List(7) { s.plusDays(it.toLong()) })
    } else {
        val off = lead(ym.atDay(1))
        (0..5).map { w -> List(7) { d -> val n = w * 7 + d - off + 1; if (n in 1..ym.lengthOfMonth()) ym.atDay(n) else null } }.filter { r -> r.any { it != null } }
    }
    val shown = if (week) YearMonth.from(sel) else ym
    val dayItems = items.filter { it.day() == sel }.sortedBy { it.start }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 64.dp, 20.dp, 180.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Календарь", 38, w = Bold)
                    T(shown.format(DateTimeFormatter.ofPattern("LLLL yyyy", ru)).replaceFirstChar { it.uppercase() }, 17, Dim)
                }
                Row(Modifier.glass(24.dp).padding(4.dp)) {
                    Chip("Месяц", !week) { week = false; ym = YearMonth.from(sel) }
                    Chip("Неделя", week) { week = true }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ChevronLeft, null, tint = Dim, modifier = Modifier.tap { if (week) sel = sel.minusWeeks(1) else ym = ym.minusMonths(1) }.padding(8.dp))
                Spacer(Modifier.weight(1f))
                Icon(Icons.Outlined.ChevronRight, null, tint = Dim, modifier = Modifier.tap { if (week) sel = sel.plusWeeks(1) else ym = ym.plusMonths(1) }.padding(8.dp))
            }
            Row { (if (S.sunday) listOf("Вс", "Пн", "Вт", "Ср", "Чт", "Пт", "Сб") else listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")).forEach { T(it, 14, Dim, m = Modifier.weight(1f), a = TextAlign.Center) } }
            rows.forEach { r ->
                Row {
                    r.forEach { date ->
                        val on = date == sel
                        Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(RoundedCornerShape(20.dp))
                            .background(if (on) Brush.linearGradient(listOf(Acc, Color(0xFF5B8CFF))) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent)))
                            .border(if (date == LocalDate.now() && !on) 1.dp else 0.dp, Dim, RoundedCornerShape(20.dp))
                            .clickable(enabled = date != null) { sel = date!! }, Alignment.Center) {
                            if (date != null) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                T("${date.dayOfMonth}", 17, w = if (on) Bold else FontWeight.Normal)
                                Row(Modifier.height(7.dp)) { items.filter { it.day() == date }.take(3).forEach { Box(Modifier.padding(1.dp).size(5.dp).clip(CircleShape).background(if (on) Color.White else Palette[it.color])) } }
                            }
                        }
                    }
                }
            }
            T(sel.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", ru)).replaceFirstChar { it.uppercase() }, 19, w = Semi, m = Modifier.padding(top = 14.dp))
        }
        if (dayItems.isEmpty()) item { T("В этот день свободно", 15, Dim) }
        items(dayItems, key = { it.id }) { i -> Strip(i, Modifier.animateItem(), open) }
        item {
            Row(Modifier.fillMaxWidth().tap { open(Item(title = "", start = sel.atTime(12, 0).ms())) }.glass(26.dp).padding(18.dp), Arrangement.Center, Alignment.CenterVertically) {
                Icon(Icons.Outlined.Add, null, tint = Color.White); Spacer(Modifier.width(10.dp)); T("Добавить событие", 16)
            }
        }
    }
}

@Composable fun Notes(items: List<Item>, open: (Item) -> Unit) {
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableIntStateOf(-1) }
    val list = items.filter { (cat < 0 || it.cat == cat) && (q.isBlank() || it.title.contains(q, true) || it.body.contains(q, true)) }
    LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 64.dp, 20.dp, 180.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(2) }) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Column { T("Заметки", 38, w = Bold); T("Твои мысли в одном месте", 17, Dim) }
                Row(Modifier.fillMaxWidth().glass(26.dp).padding(18.dp, 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Search, null, tint = Dim); Spacer(Modifier.width(12.dp))
                    BasicTextField(q, { q = it }, Modifier.weight(1f), singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 17.sp), cursorBrush = SolidColor(Acc),
                        decorationBox = { inner -> Box { if (q.isEmpty()) T("Поиск заметок…", 17, Dim); inner() } })
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("Все", cat < 0) { cat = -1 }
                    Cats.forEachIndexed { i, s -> Chip(s, cat == i) { cat = i } }
                }
            }
        }
        items(list, key = { it.id }) { i ->
            Column(Modifier.animateItem().fillMaxWidth().heightIn(min = 150.dp).tap { open(i) }.glass(26.dp, Palette[i.color]).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(16.dp).clip(RoundedCornerShape(6.dp)).background(Palette[i.color]))
                    T(if (i.start != null) i.rel() else Cats[i.cat.coerceIn(0, 3)], 13, Dim, m = Modifier.weight(1f), a = TextAlign.End, lines = 1)
                }
                T(i.title, 19, w = Semi, lines = 2)
                if (i.body.isNotBlank()) T(i.body, 14, Dim, lines = 3)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().height(150.dp).tap { open(Item(title = "")) }.glass(26.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.Add, null, tint = Color.White, modifier = Modifier.size(44.dp).clip(CircleShape).background(Color(0x22FFFFFF)).padding(10.dp))
                Spacer(Modifier.height(10.dp)); T("Новая заметка", 15)
            }
        }
    }
}

@Composable fun SettingsScreen(prefs: android.content.SharedPreferences) {
    @Composable fun Card(title: String, content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxWidth().glass(26.dp).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { T(title, 17, w = Semi); content() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 64.dp, 20.dp, 180.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { T("Настройки", 38, w = Bold); T("Персонализируй приложение под себя", 17, Dim) }
        item {
            Row(Modifier.fillMaxWidth().glass(28.dp).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(64.dp).glass(20.dp), Alignment.Center) { Icon(Icons.Outlined.AutoAwesome, null, tint = Acc, modifier = Modifier.size(32.dp)) }
                Spacer(Modifier.width(16.dp))
                Column { T("Moment", 22, w = Semi); T("Версия 1.1.0", 15, Dim) }
            }
        }
        item {
            Card("Акцентный цвет") {
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Palette.forEachIndexed { i, c ->
                        Box(Modifier.size(38.dp).tap { S.accent = i; prefs.edit().putInt("a", i).apply() }.clip(CircleShape).background(c)
                            .border(if (S.accent == i) 3.dp else 0.dp, Color.White, CircleShape))
                    }
                }
            }
        }
        item {
            Card("Первый день недели") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Chip("Понедельник", !S.sunday) { S.sunday = false; prefs.edit().putBoolean("s", false).apply() }
                    Chip("Воскресенье", S.sunday) { S.sunday = true; prefs.edit().putBoolean("s", true).apply() }
                }
            }
        }
        item { Card("Данные") { T("Все записи хранятся только на этом устройстве. Нажми на запись, чтобы изменить или удалить её; удаление можно отменить.", 14, Dim) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Editor(src: Item, onSave: (Item) -> Unit, onDelete: (Item) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(src.title) }
    var body by remember { mutableStateOf(src.body) }
    var place by remember { mutableStateOf(src.place) }
    var color by remember { mutableIntStateOf(src.color) }
    var cat by remember { mutableIntStateOf(src.cat) }
    var min by remember { mutableIntStateOf(src.minutes) }
    var at by remember { mutableStateOf(src.dt()?.toLocalDateTime()) }
    val base = at ?: LocalDateTime.now().plusHours(1).truncatedTo(ChronoUnit.HOURS)
    fun pickDate() = DatePickerDialog(ctx, { _, y, m, d -> at = LocalDateTime.of(y, m + 1, d, base.hour, base.minute) }, base.year, base.monthValue - 1, base.dayOfMonth).show()
    fun pickTime() = TimePickerDialog(ctx, { _, h, mi -> at = LocalDateTime.of(base.toLocalDate(), LocalTime.of(h, mi)) }, base.hour, base.minute, true).show()
    val clear = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent, focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
    ModalBottomSheet(onClose, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = Color(0xFF12102A)) {
        Column(Modifier.verticalScroll(rememberScrollState()).imePadding().navigationBarsPadding().padding(horizontal = 20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            T(if (src.id == 0L) "Новая запись" else "Редактирование", 14, Dim, m = Modifier.padding(start = 16.dp))
            TextField(title, { title = it }, Modifier.fillMaxWidth(), placeholder = { Text("Что запланировать?") }, textStyle = TextStyle(fontSize = 22.sp, fontWeight = Bold), singleLine = true, colors = clear)
            TextField(body, { body = it }, Modifier.fillMaxWidth(), placeholder = { Text("Текст заметки") }, minLines = 2, colors = clear)
            TextField(place, { place = it }, Modifier.fillMaxWidth(), placeholder = { Text("Место") }, singleLine = true, colors = clear)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Без даты", at == null) { at = null }
                Chip("Сегодня", at?.toLocalDate() == LocalDate.now()) { at = LocalDateTime.of(LocalDate.now(), base.toLocalTime()) }
                Chip("Завтра", at?.toLocalDate() == LocalDate.now().plusDays(1)) { at = LocalDateTime.of(LocalDate.now().plusDays(1), base.toLocalTime()) }
                Chip(at?.format(DateTimeFormatter.ofPattern("d MMM", ru)) ?: "Дата…", false) { pickDate() }
                at?.let { Chip(it.format(DateTimeFormatter.ofPattern("HH:mm")), true) { pickTime() } }
            }
            if (at != null) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30 to "30 мин", 60 to "1 час", 90 to "90 мин", 120 to "2 часа").forEach { (v, s) -> Chip(s, min == v) { min = v } }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { Cats.forEachIndexed { i, s -> Chip(s, cat == i) { cat = i } } }
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(start = 8.dp, top = 4.dp)) {
                Palette.forEachIndexed { i, c -> Box(Modifier.size(34.dp).tap { color = i }.clip(CircleShape).background(c).border(if (color == i) 3.dp else 0.dp, Color.White, CircleShape)) }
            }
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (src.id != 0L) Box(Modifier.size(52.dp).tap { onDelete(src) }.glass(26.dp), Alignment.Center) { Icon(Icons.Outlined.Delete, null, tint = Color(0xFFFF8FB8)) }
                Button({ onSave(src.copy(title = title.trim(), body = body.trim(), place = place.trim(), color = color, cat = cat, minutes = min, start = at?.ms())) },
                    Modifier.weight(1f).height(52.dp), enabled = title.isNotBlank()) { Text("Готово", fontSize = 16.sp) }
            }
        }
    }
}
