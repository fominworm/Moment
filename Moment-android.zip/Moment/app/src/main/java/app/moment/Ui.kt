package app.moment
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import java.time.*
import java.time.format.DateTimeFormatter

val Accent = Color(0xFF7C5CE6)
val Dim = Color(0x99FFFFFF)
val Palette = listOf(Color(0xFFB794FF), Color(0xFF7FB6FF), Color(0xFF7DF0C0), Color(0xFFFFB38A), Color(0xFFFF8FB8))

/** Стекло: полупрозрачный градиент + тонкая светлая кромка. */
fun Modifier.glass(r: Dp = 28.dp): Modifier {
    val s = RoundedCornerShape(r)
    return clip(s).background(Brush.linearGradient(listOf(Color(0x2AFFFFFF), Color(0x0CFFFFFF))))
        .border(1.dp, Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x0EFFFFFF))), s)
}

@Composable fun T(s: String, size: Int, c: Color = Color.White, w: FontWeight = FontWeight.Normal,
                  m: Modifier = Modifier, lines: Int = Int.MAX_VALUE, a: TextAlign? = null) =
    Text(s, m, c, size.sp, fontWeight = w, maxLines = lines, textAlign = a)

fun Modifier.onHold(f: () -> Unit) = pointerInput(Unit) { detectTapGestures(onLongPress = { f() }) }

@Composable fun Strip(i: Item, del: (Item) -> Unit) {
    val c = Palette[i.color]
    Row(Modifier.fillMaxWidth().glass(24.dp).onHold { del(i) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(46.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(14.dp))
        Column {
            T(i.whenText(), 13, c)
            T(i.title, 19, w = FontWeight.SemiBold, lines = 1)
            if (i.body.isNotBlank()) T(i.body, 14, Dim, lines = 1)
        }
    }
}

@Composable fun Home(items: List<Item>, del: (Item) -> Unit) {
    val now = System.currentTimeMillis()
    val soon = items.filter { it.start != null && it.start >= now }.sortedBy { it.start }.take(3)
    val notes = items.filter { it.start == null }.take(3)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 56.dp, 20.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            T(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE · d MMMM", ru)).replaceFirstChar { it.uppercase() }, 16, Dim)
            T("Твой день.", 44, w = FontWeight.Bold)
        }
        item { T("Ближайшее", 20, m = Modifier.padding(top = 12.dp)) }
        if (soon.isEmpty()) item { T("Пока пусто. Нажми +", 15, Dim) }
        items(soon, key = { it.id }) { Strip(it, del) }
        item { T("Твои заметки", 20, m = Modifier.padding(top = 12.dp)) }
        items(notes, key = { it.id }) { Strip(it, del) }
    }
}

@Composable fun Cal(items: List<Item>, del: (Item) -> Unit) {
    var sel by remember { mutableStateOf(LocalDate.now()) }
    var ym by remember { mutableStateOf(YearMonth.now()) }
    fun Item.day() = start?.let { Instant.ofEpochMilli(it).atZone(ZoneId.systemDefault()).toLocalDate() }
    val offset = ym.atDay(1).dayOfWeek.value - 1
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 56.dp, 20.dp, 150.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Календарь", 36, w = FontWeight.Bold)
                    T(ym.format(DateTimeFormatter.ofPattern("LLLL yyyy", ru)).replaceFirstChar { it.uppercase() }, 16, Dim)
                }
                TextButton({ ym = ym.minusMonths(1) }) { T("‹", 28) }
                TextButton({ ym = ym.plusMonths(1) }) { T("›", 28) }
            }
            Row(Modifier.padding(top = 20.dp)) { listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс").forEach { T(it, 14, Dim, m = Modifier.weight(1f), a = TextAlign.Center) } }
            for (w in 0..5) Row {
                for (d in 0..6) {
                    val n = w * 7 + d - offset + 1
                    val date = if (n in 1..ym.lengthOfMonth()) ym.atDay(n) else null
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (date == sel) Accent else Color.Transparent)
                        .clickable(enabled = date != null) { sel = date!! }, Alignment.Center) {
                        if (date != null) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            T("$n", 17)
                            Row { items.filter { it.day() == date }.take(3).forEach { Box(Modifier.padding(1.dp).size(5.dp).clip(CircleShape).background(Palette[it.color])) } }
                        }
                    }
                }
            }
            T(sel.format(DateTimeFormatter.ofPattern("EEEE, d MMMM", ru)).replaceFirstChar { it.uppercase() }, 18, m = Modifier.padding(vertical = 16.dp))
        }
        items(items.filter { it.day() == sel }, key = { it.id }) { Box(Modifier.padding(bottom = 10.dp)) { Strip(it, del) } }
    }
}

@Composable fun Notes(items: List<Item>, del: (Item) -> Unit) {
    LazyVerticalGrid(GridCells.Fixed(2), Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp, 56.dp, 20.dp, 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(2) }) { Column { T("Заметки", 36, w = FontWeight.Bold); T("Твои мысли в одном месте", 16, Dim, m = Modifier.padding(bottom = 8.dp)) } }
        items(items, key = { it.id }) { i ->
            Column(Modifier.fillMaxWidth().heightIn(min = 130.dp).glass(24.dp).onHold { del(i) }.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).clip(RoundedCornerShape(5.dp)).background(Palette[i.color]))
                    T(if (i.start != null) i.whenText() else "", 12, Dim, m = Modifier.weight(1f), a = TextAlign.End)
                }
                T(i.title, 18, w = FontWeight.SemiBold, lines = 2)
                if (i.body.isNotBlank()) T(i.body, 14, Dim, lines = 3)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddSheet(done: (Item?) -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var color by remember { mutableIntStateOf(0) }
    var at by remember { mutableStateOf<LocalDateTime?>(null) }
    val clear = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
    ModalBottomSheet({ done(null) }, containerColor = Color(0xFF14122A)) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 28.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TextField(title, { title = it }, Modifier.fillMaxWidth(), placeholder = { Text("Что запланировать?") }, singleLine = true, colors = clear)
            TextField(body, { body = it }, Modifier.fillMaxWidth(), placeholder = { Text("Текст заметки") }, colors = clear, minLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(start = 16.dp, top = 6.dp)) {
                Palette.forEachIndexed { i, c ->
                    Box(Modifier.size(32.dp).clip(CircleShape).background(c).border(if (color == i) 3.dp else 0.dp, Color.White, CircleShape).clickable { color = i })
                }
            }
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f).glass(20.dp).clickable {
                    val n = LocalDate.now()
                    DatePickerDialog(ctx, { _, y, m, d ->
                        TimePickerDialog(ctx, { _, h, min -> at = LocalDateTime.of(y, m + 1, d, h, min) }, 12, 0, true).show()
                    }, n.year, n.monthValue - 1, n.dayOfMonth).show()
                }.padding(14.dp)) { T(at?.format(DateTimeFormatter.ofPattern("d MMM, HH:mm", ru)) ?: "Без даты", 15) }
                Spacer(Modifier.width(12.dp))
                Button({
                    if (title.isNotBlank()) done(Item(title = title.trim(), body = body.trim(), color = color,
                        start = at?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()))
                }) { Text("Готово") }
            }
        }
    }
}
